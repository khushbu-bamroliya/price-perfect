import react from 'react';
import ResultRevenueLogo from './Images/ResultRevenueLogo.png'
import loginImage from './Images/Group-45.png'
import { Link, Button, TextField } from '@mui/material';
import priceperfectimg from './Images/priceperfectimg.png';

export default function ResultPage() {

    return (
        <>

            <div className='alldetails'>
                <div className="signupimages">
                <div className='priceperfactimg'>
                    <img src={priceperfectimg} width='100%'/>
                    <h3 className=''>PricePerfect</h3>
                </div>
                    <img src={loginImage} width='100%' />
                </div>

                <div className='signupdetails'>
                <div className='mb-49 flex'>
                    <h3 className='signText mb-12'>Give them the results  here.</h3>
                    <p className='accountText'>Calculate your expected revenue increase below!</p>
                </div>
                <div className='result-wrapper'>
                    <div className='wrapper'>
                        <img src={ResultRevenueLogo}  />
                        <span>Your revenue is expected to increase by ×% to Sxxx per day</span>
                    </div>
                    <div className='wrapper'>
                        <img src={ResultRevenueLogo}  />
                        <span>That is Sxxx per month in additional revenue and Sxxx per year!</span>
                    </div>
                </div>
                <div className='mb-41'>
                    <div className='daily-wrapper'>
                        <span>Daily Revenue</span>
                        <div>XXXX</div>
                    </div>
                    <div className='daily-wrapper'>
                        <span>Daily Traffic</span>
                        <div>XXXX</div>
                    </div>
                    <div className='daily-wrapper'>
                        <span>Avg order value</span>
                        <div>XXXX</div>
                    </div>
                    <div className='daily-wrapper'>
                        <span>Conversion rate</span>
                        <div>XXXX</div>
                    </div>
                </div>
                    <Button variant='contained' className='createaccountdiv text-trans'>Get Started Now!</Button>
                </div>
            </div>
        </>
    )

}