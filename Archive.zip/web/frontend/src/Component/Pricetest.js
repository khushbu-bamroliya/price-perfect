import react from 'react';
import WelcomePage from './WelcomePage.js'

export default function Pricetest() {
    return(
        <>
        <WelcomePage />
        </>
    )
}